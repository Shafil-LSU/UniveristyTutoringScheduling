﻿namespace EFCode.Models
{
    public class TimeSlot
    {
        public DateTime Date { get; set; }
        public string Time { get; set; }
    }
}
