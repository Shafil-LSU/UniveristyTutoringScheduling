﻿namespace EFCode.Models
{
    public class LoginModel
    {
    }
}
