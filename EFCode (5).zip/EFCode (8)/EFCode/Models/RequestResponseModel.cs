﻿namespace EFCode.Models
{
    public class RequestResponseModel
    {
        public string RequestStatus { get; set; }
    }
}
