﻿namespace EFCode.Models
{
    public class NotificationsModel
    {
        public List<string> message { get; set; }
    }
}
